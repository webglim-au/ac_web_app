// AdminRolesPage.tsx
import { Box, Typography } from "@mui/material";
import ScreenTemplate from "@sharedComponents/common/ScreenTemplate";
export function AdminRolesPage() {
    return (
        <ScreenTemplate>

            <Box sx={{ p: 2, backgroundColor: "white", borderRadius: 2, m: 2 }}>
                <Typography>Roles Page here</Typography>
            </Box>
        </ScreenTemplate>
    );
}