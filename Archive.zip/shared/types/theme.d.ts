import "@mui/material/styles";

declare module "@mui/material/styles" {
  interface TypeText {
    tertiary: string;
    lighterGrey: string;
  }
}
