interface IProps {
  color?: string;
}
const CalendarIcon = ({ color = "white" }: IProps) => {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill={`${color}`} xmlns="http://www.w3.org/2000/svg">
      <path d="M11.875 6.25V0H20V6.25H11.875ZM0 10V0H8.125V10H0ZM11.875 20V10H20V20H11.875ZM0 20V13.75H8.125V20H0Z" fill={`${color}`} />
    </svg>

  );
};

export default CalendarIcon;
